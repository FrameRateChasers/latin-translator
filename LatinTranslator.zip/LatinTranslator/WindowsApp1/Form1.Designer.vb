﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnLeft = New System.Windows.Forms.Button()
        Me.btnCenter = New System.Windows.Forms.Button()
        Me.btnRight = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblWord = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnLeft
        '
        Me.btnLeft.BackColor = System.Drawing.Color.SteelBlue
        Me.btnLeft.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLeft.ForeColor = System.Drawing.Color.Yellow
        Me.btnLeft.Location = New System.Drawing.Point(48, 216)
        Me.btnLeft.Name = "btnLeft"
        Me.btnLeft.Size = New System.Drawing.Size(142, 70)
        Me.btnLeft.TabIndex = 0
        Me.btnLeft.Text = "SINISTER"
        Me.btnLeft.UseVisualStyleBackColor = False
        '
        'btnCenter
        '
        Me.btnCenter.BackColor = System.Drawing.Color.SteelBlue
        Me.btnCenter.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCenter.ForeColor = System.Drawing.Color.Yellow
        Me.btnCenter.Location = New System.Drawing.Point(196, 216)
        Me.btnCenter.Name = "btnCenter"
        Me.btnCenter.Size = New System.Drawing.Size(142, 70)
        Me.btnCenter.TabIndex = 1
        Me.btnCenter.Text = "MEDIUM"
        Me.btnCenter.UseVisualStyleBackColor = False
        '
        'btnRight
        '
        Me.btnRight.BackColor = System.Drawing.Color.SteelBlue
        Me.btnRight.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRight.ForeColor = System.Drawing.Color.Yellow
        Me.btnRight.Location = New System.Drawing.Point(344, 216)
        Me.btnRight.Name = "btnRight"
        Me.btnRight.Size = New System.Drawing.Size(142, 70)
        Me.btnRight.TabIndex = 2
        Me.btnRight.Text = "DEXTER"
        Me.btnRight.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.SteelBlue
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Yellow
        Me.btnClose.Location = New System.Drawing.Point(196, 303)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(142, 70)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "EXIT"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'lblWord
        '
        Me.lblWord.Font = New System.Drawing.Font("Microsoft Sans Serif", 45.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWord.ForeColor = System.Drawing.Color.Crimson
        Me.lblWord.Location = New System.Drawing.Point(24, 26)
        Me.lblWord.Name = "lblWord"
        Me.lblWord.Size = New System.Drawing.Size(479, 72)
        Me.lblWord.TabIndex = 4
        Me.lblWord.Text = "TRANSLATION"
        Me.lblWord.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblWord.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(532, 387)
        Me.Controls.Add(Me.lblWord)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnRight)
        Me.Controls.Add(Me.btnCenter)
        Me.Controls.Add(Me.btnLeft)
        Me.Name = "Form1"
        Me.Text = "Latin Translator"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnLeft As Button
    Friend WithEvents btnCenter As Button
    Friend WithEvents btnRight As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents lblWord As Label
End Class
