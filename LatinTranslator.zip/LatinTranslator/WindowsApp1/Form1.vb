﻿Public Class Form1
    Private Sub btnLeft_Click(sender As Object, e As EventArgs) Handles btnLeft.Click
        lblWord.Text = "LEFT"
        lblWord.Visible = True
        lblWord.TextAlign = ContentAlignment.MiddleLeft

    End Sub

    Private Sub btnCenter_Click(sender As Object, e As EventArgs) Handles btnCenter.Click
        lblWord.Text = "MIDDLE"
        lblWord.Visible = True
        lblWord.TextAlign = ContentAlignment.MiddleCenter


    End Sub

    Private Sub btnRight_Click(sender As Object, e As EventArgs) Handles btnRight.Click
        lblWord.Text = "RIGHT"
        lblWord.Visible = True
        lblWord.TextAlign = ContentAlignment.MiddleRight



    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class
